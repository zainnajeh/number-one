import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FloatingButtons } from "@/components/FloatingButtons";
import { ProductCard } from "@/components/ProductCard";
import { useStore } from "@/data/store";

export const Route = createFileRoute("/category/$slug")({
  component: CategoryPage,
  notFoundComponent: () => (
    <div dir="rtl" className="min-h-screen bg-background">
      <Header />
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="text-6xl">🗂️</p>
        <h1 className="mt-4 text-2xl font-black">القسم غير موجود</h1>
        <Link to="/products" className="mt-6 inline-block rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground">كل المنتجات</Link>
      </div>
      <Footer />
    </div>
  ),
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const categories = useStore((s) => s.categories);
  const products = useStore((s) => s.products);
  const category = categories.find((c) => c.slug === slug);
  const categoryProducts = category ? products.filter((p) => p.categoryId === category.id) : [];
  if (!category) throw notFound();


  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />
      <div className="mx-auto max-w-7xl px-4 py-8">
        <nav className="mb-4 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-primary">الرئيسية</Link>
          <span className="mx-2">←</span>
          <Link to="/products" className="hover:text-primary">المنتجات</Link>
          <span className="mx-2">←</span>
          <span className="text-foreground">{category.name}</span>
        </nav>

        <div className={`mb-8 flex items-center gap-4 rounded-3xl border p-6 ${category.color}`}>
          <div className="grid size-16 place-items-center rounded-2xl bg-white text-4xl shadow-sm sm:size-20 sm:text-5xl">
            {category.emoji}
          </div>
          <div>
            <h1 className="text-2xl font-black sm:text-3xl">{category.name}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{categoryProducts.length} منتج متوفر في هذا القسم</p>
          </div>
        </div>

        {categoryProducts.length === 0 ? (
          <div className="grid place-items-center rounded-3xl border border-dashed border-border bg-card py-20 text-center">
            <p className="text-5xl">📦</p>
            <p className="mt-3 text-lg font-bold">لا توجد منتجات في هذا القسم بعد</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4 xl:grid-cols-5">
            {categoryProducts.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </div>
      <Footer />
      <FloatingButtons />
    </div>
  );
}
