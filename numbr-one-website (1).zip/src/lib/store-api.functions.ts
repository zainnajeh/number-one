import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/* ---------------- schemas ---------------- */

const passwordField = z.string().min(1);

const productInput = z.object({
  name: z.string().min(1),
  categoryId: z.string().uuid().nullable().optional(),
  price: z.number().nonnegative(),
  oldPrice: z.number().nonnegative().nullable().optional(),
  unit: z.string().min(1),
  availability: z.enum(["available", "low", "out"]),
  featured: z.boolean().optional(),
  description: z.string().default(""),
  images: z.array(z.string()).default([]),
  emoji: z.string().default("🛒"),
});

const categoryInput = z.object({
  slug: z.string().min(1),
  name: z.string().min(1),
  emoji: z.string().default("🛒"),
  color: z.string().default("bg-slate-50 border-slate-100"),
  sortOrder: z.number().int().optional(),
});

const bannerInput = z.object({
  title: z.string().min(1),
  subtitle: z.string().default(""),
  cta: z.string().default("تسوق الآن"),
  gradient: z.string().default("from-primary to-emerald-700"),
  sortOrder: z.number().int().optional(),
});

const infoInput = z.object({
  name: z.string().optional(),
  tagline: z.string().optional(),
  address: z.string().optional(),
  phone: z.string().optional(),
  whatsapp: z.string().optional(),
  hours: z.string().optional(),
  email: z.string().optional(),
  mapEmbed: z.string().optional(),
});

function checkPassword(pw: string) {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) throw new Error("ADMIN_PASSWORD not configured");
  if (pw !== expected) throw new Error("كلمة المرور غير صحيحة");
}

/* ---------------- verifyPassword ---------------- */

export const verifyAdminPassword = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ password: passwordField }).parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    return { ok: true };
  });

/* ---------------- Products ---------------- */

export const createProduct = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ password: passwordField, product: productInput }).parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const p = data.product;
    const { data: row, error } = await supabaseAdmin
      .from("products")
      .insert({
        name: p.name,
        category_id: p.categoryId ?? null,
        price: p.price,
        old_price: p.oldPrice ?? null,
        unit: p.unit,
        availability: p.availability,
        featured: p.featured ?? false,
        description: p.description,
        images: p.images,
        emoji: p.emoji,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateProduct = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({ password: passwordField, id: z.string().uuid(), patch: productInput.partial() }).parse(d),
  )
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const p = data.patch;
    const { error } = await supabaseAdmin
      .from("products")
      .update({
        ...(p.name !== undefined && { name: p.name }),
        ...(p.categoryId !== undefined && { category_id: p.categoryId }),
        ...(p.price !== undefined && { price: p.price }),
        ...(p.oldPrice !== undefined && { old_price: p.oldPrice }),
        ...(p.unit !== undefined && { unit: p.unit }),
        ...(p.availability !== undefined && { availability: p.availability }),
        ...(p.featured !== undefined && { featured: p.featured }),
        ...(p.description !== undefined && { description: p.description }),
        ...(p.images !== undefined && { images: p.images }),
        ...(p.emoji !== undefined && { emoji: p.emoji }),
      })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ password: passwordField, id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("products").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------------- Categories ---------------- */

export const createCategory = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ password: passwordField, category: categoryInput }).parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const c = data.category;
    const { data: row, error } = await supabaseAdmin
      .from("categories")
      .insert({
        slug: c.slug,
        name: c.name,
        emoji: c.emoji,
        color: c.color,
        sort_order: c.sortOrder ?? 999,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteCategory = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ password: passwordField, id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("categories").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------------- Banners ---------------- */

export const createBanner = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ password: passwordField, banner: bannerInput }).parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const b = data.banner;
    const { data: row, error } = await supabaseAdmin
      .from("banners")
      .insert({
        title: b.title,
        subtitle: b.subtitle,
        cta: b.cta,
        gradient: b.gradient,
        sort_order: b.sortOrder ?? 999,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteBanner = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ password: passwordField, id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("banners").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------------- Image upload ---------------- */

const uploadInput = z.object({
  password: passwordField,
  fileName: z.string().min(1),
  contentType: z.string().min(1),
  // base64-encoded file bytes (no data: prefix)
  base64: z.string().min(1),
});

export const uploadProductImage = createServerFn({ method: "POST" })
  .inputValidator((d) => uploadInput.parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // sanitize filename & make it unique
    const safe = data.fileName.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
    const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safe}`;

    const bytes = Uint8Array.from(atob(data.base64), (c) => c.charCodeAt(0));

    const { error: upErr } = await supabaseAdmin.storage
      .from("product-images")
      .upload(path, bytes, { contentType: data.contentType, upsert: false });
    if (upErr) throw new Error(upErr.message);

    // 10-year signed URL for public display
    const { data: signed, error: sErr } = await supabaseAdmin.storage
      .from("product-images")
      .createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
    if (sErr || !signed) throw new Error(sErr?.message ?? "signed url failed");

    return { url: signed.signedUrl, path };
  });


/* ---------------- Store info ---------------- */

export const updateStoreInfo = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ password: passwordField, patch: infoInput }).parse(d))
  .handler(async ({ data }) => {
    checkPassword(data.password);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const p = data.patch;
    const { error } = await supabaseAdmin
      .from("store_info")
      .update({
        updated_at: new Date().toISOString(),
        ...(p.name !== undefined && { name: p.name }),
        ...(p.tagline !== undefined && { tagline: p.tagline }),
        ...(p.address !== undefined && { address: p.address }),
        ...(p.phone !== undefined && { phone: p.phone }),
        ...(p.whatsapp !== undefined && { whatsapp: p.whatsapp }),
        ...(p.hours !== undefined && { hours: p.hours }),
        ...(p.email !== undefined && { email: p.email }),
        ...(p.mapEmbed !== undefined && { map_embed: p.mapEmbed }),
      })
      .eq("id", 1);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
