import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { z } from "zod";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FloatingButtons } from "@/components/FloatingButtons";
import { ProductCard } from "@/components/ProductCard";
import { useStore, type Availability } from "@/data/store";

const searchSchema = z.object({
  q: z.string().optional(),
  cat: z.string().optional(),
  min: z.coerce.number().optional(),
  max: z.coerce.number().optional(),
  avail: z.enum(["available", "low", "out"]).optional(),
  deals: z.coerce.boolean().optional(),
});

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "كل المنتجات — NUMBR ONE" },
      { name: "description", content: "تصفح جميع منتجات NUMBR ONE مع البحث والفلاتر حسب القسم والسعر والتوفر." },
    ],
  }),
  validateSearch: (search) => searchSchema.parse(search),
  component: ProductsPage,
});

function ProductsPage() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const products = useStore((s) => s.products);
  const categories = useStore((s) => s.categories);

  const [q, setQ] = useState(search.q ?? "");

  const filtered = useMemo(() => {
    return products.filter((p) => {
      if (search.q && !p.name.includes(search.q) && !p.description.includes(search.q)) return false;
      if (search.cat && p.categoryId !== search.cat) return false;
      if (search.avail && p.availability !== search.avail) return false;
      if (search.deals && !(p.oldPrice && p.oldPrice > p.price)) return false;
      if (search.min !== undefined && p.price < search.min) return false;
      if (search.max !== undefined && p.price > search.max) return false;
      return true;
    });
  }, [products, search]);

  function update(patch: Partial<z.infer<typeof searchSchema>>) {
    navigate({ search: ((prev: Record<string, unknown>) => ({ ...prev, ...patch })) as never });
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />

      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-black">كل المنتجات</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {filtered.length} منتج
            {search.q && <> · نتائج البحث عن "<span className="font-bold text-foreground">{search.q}</span>"</>}
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          {/* Filters */}
          <aside className="space-y-5 rounded-3xl border border-border bg-card p-5 shadow-soft lg:sticky lg:top-40 lg:self-start">
            <div>
              <label className="mb-2 block text-xs font-bold text-muted-foreground">بحث</label>
              <form
                onSubmit={(e) => { e.preventDefault(); update({ q: q || undefined }); }}
                className="flex gap-2"
              >
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="ابحث..."
                  className="flex-1 rounded-xl border border-border bg-secondary px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
                />
                <button type="submit" className="rounded-xl bg-primary px-3 py-2 text-sm font-bold text-primary-foreground">بحث</button>
              </form>
            </div>

            <div>
              <label className="mb-2 block text-xs font-bold text-muted-foreground">القسم</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => update({ cat: undefined })}
                  className={`rounded-full px-3 py-1 text-xs font-bold ${!search.cat ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"}`}
                >
                  الكل
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => update({ cat: search.cat === c.id ? undefined : c.id })}
                    className={`rounded-full px-3 py-1 text-xs font-bold ${search.cat === c.id ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-primary/10"}`}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="mb-2 block text-xs font-bold text-muted-foreground">السعر (د.ع)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder="من"
                  defaultValue={search.min ?? ""}
                  onBlur={(e) => update({ min: e.target.value ? Number(e.target.value) : undefined })}
                  className="w-full rounded-xl border border-border bg-secondary px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
                />
                <input
                  type="number"
                  placeholder="إلى"
                  defaultValue={search.max ?? ""}
                  onBlur={(e) => update({ max: e.target.value ? Number(e.target.value) : undefined })}
                  className="w-full rounded-xl border border-border bg-secondary px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>

            <div>
              <label className="mb-2 block text-xs font-bold text-muted-foreground">التوفر</label>
              <div className="flex flex-col gap-1.5">
                {(["available", "low", "out"] as Availability[]).map((a) => (
                  <button
                    key={a}
                    onClick={() => update({ avail: search.avail === a ? undefined : a })}
                    className={`rounded-xl px-3 py-2 text-right text-xs font-bold ${search.avail === a ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"}`}
                  >
                    {a === "available" && "متوفر"}
                    {a === "low" && "كمية محدودة"}
                    {a === "out" && "غير متوفر"}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="flex cursor-pointer items-center gap-2">
                <input
                  type="checkbox"
                  checked={!!search.deals}
                  onChange={(e) => update({ deals: e.target.checked || undefined })}
                  className="size-4 accent-primary"
                />
                <span className="text-sm font-bold">العروض والخصومات فقط</span>
              </label>
            </div>

            <button
              onClick={() => { setQ(""); navigate({ search: {} as never }); }}
              className="w-full rounded-xl border border-border py-2 text-xs font-bold text-muted-foreground hover:border-primary hover:text-primary"
            >
              إعادة تعيين
            </button>
          </aside>

          {/* Grid */}
          <div>
            {filtered.length === 0 ? (
              <div className="grid place-items-center rounded-3xl border border-dashed border-border bg-card py-24 text-center">
                <p className="text-6xl">🔍</p>
                <p className="mt-4 text-lg font-bold">لا توجد منتجات مطابقة</p>
                <p className="mt-1 text-sm text-muted-foreground">جرب تعديل الفلاتر أو البحث بكلمة أخرى</p>
                <Link to="/products" className="mt-6 rounded-xl bg-primary px-6 py-2 text-sm font-bold text-primary-foreground">عرض كل المنتجات</Link>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-4">
                {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
      <FloatingButtons />
    </div>
  );
}
