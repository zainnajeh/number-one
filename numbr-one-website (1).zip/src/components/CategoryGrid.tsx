import { Link } from "@tanstack/react-router";
import { useStore } from "@/data/store";

export function CategoryGrid() {
  const categories = useStore((s) => s.categories);
  return (
    <section className="mx-auto max-w-7xl px-4 py-10 sm:py-14">
      <div className="mb-6 flex items-end justify-between gap-4 sm:mb-8">
        <div>
          <h2 className="text-2xl font-black text-foreground sm:text-3xl">تسوق حسب الفئات</h2>
          <p className="mt-1 text-sm text-muted-foreground">14 قسم يغطي كل احتياجات منزلك</p>
        </div>
        <Link to="/products" className="text-sm font-bold text-primary hover:underline">
          عرض الكل ←
        </Link>
      </div>

      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 sm:gap-4 md:grid-cols-6 lg:grid-cols-7">
        {categories.map((c, i) => (
          <Link
            key={c.id}
            to="/category/$slug"
            params={{ slug: c.slug }}
            className="group animate-reveal"
            style={{ animationDelay: `${i * 30}ms` }}
          >
            <div className={`mb-3 grid aspect-square place-items-center rounded-3xl border ${c.color} transition group-hover:border-primary group-hover:shadow-lg group-hover:shadow-primary/10`}>
              <span className="text-4xl transition group-hover:scale-125 sm:text-5xl" aria-hidden>
                {c.emoji}
              </span>
            </div>
            <p className="text-center text-xs font-bold text-foreground sm:text-sm">{c.name}</p>
          </Link>
        ))}
      </div>
    </section>
  );
}
