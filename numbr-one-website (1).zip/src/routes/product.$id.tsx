import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FloatingButtons } from "@/components/FloatingButtons";
import { ProductCard } from "@/components/ProductCard";
import { availabilityClass, availabilityLabel, formatPrice, useStore } from "@/data/store";

export const Route = createFileRoute("/product/$id")({
  component: ProductPage,
  notFoundComponent: () => (
    <div dir="rtl" className="min-h-screen bg-background">
      <Header />
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="text-6xl">🛒</p>
        <h1 className="mt-4 text-2xl font-black">المنتج غير موجود</h1>
        <Link to="/products" className="mt-6 inline-block rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground">كل المنتجات</Link>
      </div>
      <Footer />
    </div>
  ),
});

function ProductPage() {
  const { id } = Route.useParams();
  const products = useStore((s) => s.products);
  const categories = useStore((s) => s.categories);
  const info = useStore((s) => s.info);
  const product = products.find((p) => p.id === id);
  const category = product ? categories.find((c) => c.id === product.categoryId) : undefined;
  const related = product ? products.filter((p) => p.categoryId === product.categoryId && p.id !== product.id).slice(0, 5) : [];
  const [copied, setCopied] = useState(false);


  if (!product) throw notFound();

  const isOut = product.availability === "out";
  const discount = product.oldPrice && product.oldPrice > product.price
    ? Math.round((1 - product.price / product.oldPrice) * 100)
    : null;

  const waMsg = encodeURIComponent(`مرحباً، أود الاستفسار عن المنتج: ${product.name} (${formatPrice(product.price)})`);

  function share() {
    if (typeof window === "undefined") return;
    const url = window.location.href;
    if (navigator.share) navigator.share({ title: product!.name, url }).catch(() => {});
    else { navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 1500); }
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />
      <div className="mx-auto max-w-6xl px-4 py-8">
        <nav className="mb-6 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-primary">الرئيسية</Link>
          <span className="mx-2">←</span>
          {category && (
            <>
              <Link to="/category/$slug" params={{ slug: category.slug }} className="hover:text-primary">{category.name}</Link>
              <span className="mx-2">←</span>
            </>
          )}
          <span className="text-foreground">{product.name}</span>
        </nav>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Images */}
          <div>
            <div className={`relative grid aspect-square place-items-center overflow-hidden rounded-3xl border border-border bg-secondary ${isOut ? "grayscale" : ""}`}>
              <span className="text-[10rem] sm:text-[14rem]" aria-hidden>{product.emoji}</span>
              {discount !== null && !isOut && (
                <span className="absolute top-4 left-4 rounded-full bg-destructive px-3 py-1 text-sm font-black text-destructive-foreground">
                  خصم {discount}%
                </span>
              )}
            </div>
            <div className="mt-3 grid grid-cols-4 gap-2">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="grid aspect-square place-items-center rounded-xl border border-border bg-secondary text-2xl opacity-70">
                  {product.emoji}
                </div>
              ))}
            </div>
          </div>

          {/* Info */}
          <div>
            <span className="text-xs font-bold text-muted-foreground">{category?.name}</span>
            <h1 className="mt-1 text-3xl font-black sm:text-4xl">{product.name}</h1>

            <div className="mt-3 flex items-center gap-3">
              <span className={`rounded-full border px-3 py-1 text-xs font-bold ${availabilityClass[product.availability]}`}>
                {availabilityLabel[product.availability]}
              </span>
              <span className="text-sm text-muted-foreground">الوحدة: {product.unit}</span>
            </div>

            <div className="mt-6 flex items-baseline gap-3">
              <span className="text-4xl font-black text-primary">{formatPrice(product.price)}</span>
              {product.oldPrice && (
                <span className="text-lg text-muted-foreground line-through">{formatPrice(product.oldPrice)}</span>
              )}
            </div>

            <div className="mt-6 rounded-2xl border border-border bg-card p-5">
              <h3 className="mb-2 text-sm font-bold">الوصف</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{product.description}</p>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href={`https://wa.me/${info.whatsapp}?text=${waMsg}`}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex-1 min-w-[180px] rounded-2xl bg-whatsapp py-4 text-center text-sm font-black text-white transition hover:opacity-90 ${isOut ? "opacity-60" : ""}`}
              >
                استفسار عبر واتساب
              </a>
              <a
                href={`tel:+${info.phone}`}
                className="flex-1 min-w-[180px] rounded-2xl bg-primary py-4 text-center text-sm font-black text-primary-foreground transition hover:opacity-90"
              >
                اتصل للطلب
              </a>
              <button
                onClick={share}
                className="rounded-2xl border border-border bg-card px-5 py-4 text-sm font-bold hover:border-primary hover:text-primary"
              >
                {copied ? "تم النسخ ✓" : "مشاركة"}
              </button>
            </div>

            <div className="mt-6 grid grid-cols-3 gap-3 text-center text-xs">
              <div className="rounded-xl border border-border bg-card p-3">
                <p className="text-lg">🚚</p>
                <p className="mt-1 font-bold">توصيل سريع</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-3">
                <p className="text-lg">✅</p>
                <p className="mt-1 font-bold">جودة مضمونة</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-3">
                <p className="text-lg">💳</p>
                <p className="mt-1 font-bold">دفع عند الاستلام</p>
              </div>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <section className="mt-16">
            <h2 className="mb-6 text-2xl font-black">منتجات ذات صلة</h2>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-5">
              {related.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </section>
        )}
      </div>
      <Footer />
      <FloatingButtons />
    </div>
  );
}
