import { createFileRoute, Link } from "@tanstack/react-router";
import heroImg from "@/assets/hero.jpg";
import { useStore } from "@/data/store";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FloatingButtons } from "@/components/FloatingButtons";
import { CategoryGrid } from "@/components/CategoryGrid";
import { ProductSection } from "@/components/ProductSection";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NUMBR ONE — سوبر ماركت البصرة | تسوق طازج يومياً" },
      { name: "description", content: "NUMBR ONE سوبر ماركت في البصرة يقدم أجود المنتجات الطازجة: فواكه، خضروات، لحوم، ألبان، مخبوزات وأكثر بأسعار منافسة." },
      { property: "og:title", content: "NUMBR ONE — سوبر ماركت البصرة" },
      { property: "og:description", content: "خيارك الأول للتسوق اليومي — منتجات طازجة وأسعار منافسة في البصرة." },
    ],
  }),
  component: Home,
});

function Home() {
  const products = useStore((s) => s.products);
  const banners = useStore((s) => s.banners);
  const info = useStore((s) => s.info);

  const featured = products.filter((p) => p.featured).slice(0, 10);
  const latest = [...products].sort((a, b) => b.createdAt - a.createdAt).slice(0, 10);
  const deals = products.filter((p) => p.oldPrice && p.oldPrice > p.price).slice(0, 5);

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />

      {/* Hero */}
      <section className="mx-auto max-w-7xl px-4 pt-6">
        <div className="relative overflow-hidden rounded-[2rem] bg-primary shadow-brand animate-scale-in">
          <img
            src={heroImg}
            alt="منتجات طازجة من نمبر وان"
            width={1600}
            height={900}
            className="absolute inset-0 h-full w-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-primary via-primary/85 to-primary/40" />
          <div className="relative z-10 px-6 py-14 sm:px-12 sm:py-20 md:w-2/3 lg:w-1/2">
            <span className="inline-block rounded-full bg-accent px-4 py-1 text-xs font-black text-accent-foreground">
              أهلاً بكم في {info.name}
            </span>
            <h2 className="mt-5 text-3xl font-black leading-tight text-primary-foreground sm:text-5xl md:text-6xl">
              مرحباً بكم<br />في <span className="text-accent">نمبر وان</span>
            </h2>
            <p className="mt-4 max-w-md text-base text-primary-foreground/85 sm:text-lg">
              {info.tagline}. اكتشف مجموعتنا المختارة من المنتجات الطازجة يومياً بأفضل الأسعار.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                to="/products"
                className="rounded-2xl bg-card px-6 py-3 text-sm font-black text-primary transition hover:bg-accent hover:text-accent-foreground sm:px-8 sm:py-4"
              >
                تسوق الآن
              </Link>
              <a
                href="#contact"
                className="rounded-2xl border-2 border-white/40 px-6 py-3 text-sm font-black text-primary-foreground transition hover:bg-white/10 sm:px-8 sm:py-4"
              >
                تواصل معنا
              </a>
            </div>
          </div>
        </div>
      </section>

      <CategoryGrid />

      {/* Promo banners */}
      <section className="mx-auto max-w-7xl px-4 py-6">
        <div className="grid gap-4 md:grid-cols-2">
          {banners.map((b) => (
            <div
              key={b.id}
              className={`relative overflow-hidden rounded-3xl bg-gradient-to-l ${b.gradient} p-6 text-white shadow-soft sm:p-8`}
            >
              <div className="pointer-events-none absolute -left-6 -bottom-6 size-32 rounded-full bg-white/10 blur-2xl" />
              <span className="mb-3 inline-block rounded-full bg-white/15 px-3 py-1 text-[10px] font-black uppercase tracking-widest">
                عرض خاص
              </span>
              <h3 className="text-2xl font-black sm:text-3xl">{b.title}</h3>
              <p className="mt-2 max-w-sm text-sm text-white/85 sm:text-base">{b.subtitle}</p>
              <Link
                to="/products"
                className="mt-5 inline-block rounded-xl bg-white px-5 py-2 text-sm font-black text-primary transition hover:bg-accent hover:text-accent-foreground"
              >
                {b.cta}
              </Link>
            </div>
          ))}
        </div>
      </section>

      <ProductSection title="المنتجات المميزة" subtitle="اختيارات فريقنا لهذا الأسبوع" products={featured} viewAllHref="/products" />

      {deals.length > 0 && (
        <ProductSection title="عروض حصرية" subtitle="خصومات لفترة محدودة" products={deals} viewAllHref="/products" />
      )}

      <ProductSection title="وصل حديثاً" subtitle="أحدث المنتجات على الرفوف" products={latest} viewAllHref="/products" />

      {/* Contact + Map */}
      <section id="contact" className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-soft lg:col-span-2">
            <div className="aspect-[16/10] w-full bg-secondary">
              <iframe
                title="موقع المتجر"
                src={info.mapEmbed}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-full w-full border-0"
                allowFullScreen
              />
            </div>
          </div>
          <div className="rounded-3xl border border-border bg-card p-8 shadow-soft">
            <h3 className="mb-6 text-2xl font-black">تواصل معنا</h3>
            <div className="space-y-5 text-sm">
              <div>
                <p className="mb-1 text-xs font-bold text-muted-foreground">العنوان</p>
                <p className="font-bold">{info.address}</p>
              </div>
              <div>
                <p className="mb-1 text-xs font-bold text-muted-foreground">ساعات العمل</p>
                <p className="font-bold">{info.hours}</p>
              </div>
              <div>
                <p className="mb-1 text-xs font-bold text-muted-foreground">الهاتف</p>
                <a href={`tel:+${info.phone}`} className="font-bold text-primary hover:underline" dir="ltr">+{info.phone}</a>
              </div>
              <div>
                <p className="mb-1 text-xs font-bold text-muted-foreground">البريد</p>
                <p className="font-bold" dir="ltr">{info.email}</p>
              </div>
            </div>
            <a
              href={`https://wa.me/${info.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 flex w-full items-center justify-center rounded-2xl bg-whatsapp py-3 text-sm font-black text-white transition hover:opacity-90"
            >
              مراسلتنا على واتساب
            </a>
          </div>
        </div>
      </section>

      <Footer />
      <FloatingButtons />
    </div>
  );
}
