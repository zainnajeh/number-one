import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { Header } from "@/components/Header";
import { FloatingButtons } from "@/components/FloatingButtons";
import { uploadProductImage } from "@/lib/store-api.functions";
import {
  availabilityLabel,
  formatPrice,
  useStore,
  type Availability,
  type Product,
} from "@/data/store";


export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "لوحة تحكم المدير — NUMBR ONE" }, { name: "robots", content: "noindex" }] }),
  component: AdminPage,
});

function AdminPage() {
  const isAdmin = useStore((s) => s.isAdmin);
  if (!isAdmin) return <LoginGate />;
  return <Dashboard />;
}

function LoginGate() {
  const login = useStore((s) => s.login);
  const [pw, setPw] = useState("");
  const [err, setErr] = useState(false);
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="mx-auto grid max-w-md px-4 py-20">
        <div className="rounded-3xl border border-border bg-card p-8 shadow-brand">
          <div className="mb-6 text-center">
            <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-primary text-3xl text-primary-foreground">🔐</div>
            <h1 className="mt-4 text-2xl font-black">تسجيل دخول المدير</h1>
            <p className="mt-1 text-sm text-muted-foreground">أدخل كلمة المرور للوصول للوحة التحكم</p>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!login(pw)) setErr(true);
            }}
            className="space-y-4"
          >
            <input
              type="password"
              value={pw}
              onChange={(e) => { setPw(e.target.value); setErr(false); }}
              placeholder="كلمة المرور"
              className="w-full rounded-xl border border-border bg-secondary px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary"
              autoFocus
            />
            {err && <p className="text-xs font-bold text-destructive">كلمة المرور غير صحيحة</p>}
            <button className="w-full rounded-xl bg-primary py-3 text-sm font-black text-primary-foreground hover:opacity-90">
              دخول
            </button>
            <p className="rounded-xl bg-accent/30 p-3 text-center text-xs text-accent-foreground">
              كلمة المرور الافتراضية: <b>admin123</b>
            </p>
          </form>
        </div>
      </div>
      <FloatingButtons />
    </div>
  );
}

type Tab = "products" | "categories" | "banners" | "info";

function Dashboard() {
  const [tab, setTab] = useState<Tab>("products");
  const logout = useStore((s) => s.logout);
  const resetAll = useStore((s) => s.resetAll);
  const products = useStore((s) => s.products);
  const categories = useStore((s) => s.categories);
  const banners = useStore((s) => s.banners);
  const stats = useMemo(() => ({
    products: products.length,
    categories: categories.length,
    banners: banners.length,
    out: products.filter((p) => p.availability === "out").length,
  }), [products, categories, banners]);


  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-black">لوحة تحكم المدير</h1>
            <p className="mt-1 text-sm text-muted-foreground">إدارة المنتجات، الأقسام، العروض، ومعلومات المتجر</p>
          </div>
          <div className="flex gap-2">
            <Link to="/" className="rounded-xl border border-border bg-card px-4 py-2 text-sm font-bold hover:border-primary">
              معاينة الموقع
            </Link>
            <button
              onClick={() => confirm("إعادة كل البيانات للحالة الافتراضية؟") && resetAll()}
              className="rounded-xl border border-border bg-card px-4 py-2 text-sm font-bold hover:border-destructive hover:text-destructive"
            >
              إعادة تعيين
            </button>
            <button onClick={logout} className="rounded-xl bg-destructive px-4 py-2 text-sm font-bold text-destructive-foreground hover:opacity-90">
              خروج
            </button>
          </div>
        </div>

        {/* Stat cards */}
        <div className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-4">
          <StatCard label="منتجات" value={stats.products} emoji="📦" />
          <StatCard label="أقسام" value={stats.categories} emoji="🗂️" />
          <StatCard label="عروض" value={stats.banners} emoji="🎁" />
          <StatCard label="غير متوفر" value={stats.out} emoji="⚠️" accent />
        </div>

        {/* Tabs */}
        <div className="mb-6 flex flex-wrap gap-2 border-b border-border">
          {(["products", "categories", "banners", "info"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-t-xl px-5 py-3 text-sm font-bold transition ${tab === t ? "border-b-2 border-primary text-primary" : "text-muted-foreground hover:text-foreground"}`}
            >
              {t === "products" && "المنتجات"}
              {t === "categories" && "الأقسام"}
              {t === "banners" && "البانرات"}
              {t === "info" && "معلومات المتجر"}
            </button>
          ))}
        </div>

        {tab === "products" && <ProductsAdmin />}
        {tab === "categories" && <CategoriesAdmin />}
        {tab === "banners" && <BannersAdmin />}
        {tab === "info" && <InfoAdmin />}
      </div>
      <FloatingButtons />
    </div>
  );
}

function StatCard({ label, value, emoji, accent }: { label: string; value: number; emoji: string; accent?: boolean }) {
  return (
    <div className={`rounded-2xl border p-5 ${accent ? "border-destructive/30 bg-destructive/5" : "border-border bg-card"}`}>
      <div className="flex items-center justify-between">
        <span className="text-2xl">{emoji}</span>
        <span className="text-3xl font-black">{value}</span>
      </div>
      <p className="mt-2 text-xs font-bold text-muted-foreground">{label}</p>
    </div>
  );
}

/* -------------------- Products -------------------- */

function ProductsAdmin() {
  const products = useStore((s) => s.products);
  const categories = useStore((s) => s.categories);
  const addProduct = useStore((s) => s.addProduct);
  const updateProduct = useStore((s) => s.updateProduct);
  const deleteProduct = useStore((s) => s.deleteProduct);
  const [editing, setEditing] = useState<Product | "new" | null>(null);

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-black">{products.length} منتج</h2>
        <button
          onClick={() => setEditing("new")}
          className="rounded-xl bg-primary px-5 py-2 text-sm font-bold text-primary-foreground hover:opacity-90"
        >
          + إضافة منتج
        </button>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-border bg-card">
        <table className="w-full text-right text-sm">
          <thead className="border-b border-border bg-secondary text-xs">
            <tr>
              <th className="p-3">المنتج</th>
              <th className="p-3">القسم</th>
              <th className="p-3">السعر</th>
              <th className="p-3">التوفر</th>
              <th className="p-3">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => {
              const cat = categories.find((c) => c.id === p.categoryId);
              return (
                <tr key={p.id} className="border-b border-border/60 last:border-b-0">
                  <td className="p-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{p.emoji}</span>
                      <div>
                        <p className="font-bold">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{p.unit}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-3 text-xs text-muted-foreground">{cat?.name ?? "-"}</td>
                  <td className="p-3 font-bold text-primary">{formatPrice(p.price)}</td>
                  <td className="p-3 text-xs">{availabilityLabel[p.availability]}</td>
                  <td className="p-3">
                    <div className="flex gap-1">
                      <button onClick={() => setEditing(p)} className="rounded-lg bg-secondary px-3 py-1 text-xs font-bold hover:bg-primary hover:text-primary-foreground">تعديل</button>
                      <button
                        onClick={() => confirm(`حذف "${p.name}"؟`) && deleteProduct(p.id)}
                        className="rounded-lg bg-destructive/10 px-3 py-1 text-xs font-bold text-destructive hover:bg-destructive hover:text-destructive-foreground"
                      >
                        حذف
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {editing && (
        <ProductForm
          initial={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSave={(data) => {
            if (editing === "new") addProduct(data);
            else updateProduct(editing.id, data);
            setEditing(null);
          }}
        />
      )}
    </div>
  );
}

function ProductForm({
  initial,
  onSave,
  onClose,
}: {
  initial: Product | null;
  onSave: (p: Omit<Product, "id" | "createdAt">) => void;
  onClose: () => void;
}) {
  const categories = useStore((s) => s.categories);
  const adminPassword = useStore((s) => s.adminPassword);
  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState<string | null>(null);
  const [form, setForm] = useState<Omit<Product, "id" | "createdAt">>({
    name: initial?.name ?? "",
    categoryId: initial?.categoryId ?? categories[0]?.id ?? "",
    price: initial?.price ?? 1000,
    oldPrice: initial?.oldPrice,
    unit: initial?.unit ?? "قطعة",
    availability: initial?.availability ?? "available",
    featured: initial?.featured ?? false,
    description: initial?.description ?? "",
    images: initial?.images ?? [],
    emoji: initial?.emoji ?? "📦",
  });

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0 || !adminPassword) return;
    setUploading(true);
    setUploadErr(null);
    try {
      const uploaded: string[] = [];
      for (const file of Array.from(files)) {
        if (file.size > 5 * 1024 * 1024) throw new Error(`الملف "${file.name}" أكبر من 5MB`);
        const buf = await file.arrayBuffer();
        let binary = "";
        const bytes = new Uint8Array(buf);
        for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
        const base64 = btoa(binary);
        const res = await uploadProductImage({
          data: {
            password: adminPassword,
            fileName: file.name,
            contentType: file.type || "image/jpeg",
            base64,
          },
        });
        uploaded.push(res.url);
      }
      setForm((f) => ({ ...f, images: [...f.images, ...uploaded] }));
    } catch (e) {
      setUploadErr(e instanceof Error ? e.message : "فشل رفع الصور");
    } finally {
      setUploading(false);
    }
  }


  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-card p-6 shadow-brand sm:p-8"
      >
        <div className="mb-6 flex items-center justify-between">
          <h3 className="text-xl font-black">{initial ? "تعديل منتج" : "إضافة منتج جديد"}</h3>
          <button onClick={onClose} className="rounded-lg bg-secondary px-3 py-1 text-sm font-bold">✕</button>
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); onSave(form); }}
          className="space-y-4"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="اسم المنتج">
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} />
            </Field>
            <Field label="الأيقونة (إيموجي)">
              <input value={form.emoji} onChange={(e) => setForm({ ...form, emoji: e.target.value })} className={inputCls} />
            </Field>
            <Field label="القسم">
              <select value={form.categoryId ?? ""} onChange={(e) => setForm({ ...form, categoryId: e.target.value || null })} className={inputCls}>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </Field>
            <Field label="الوحدة">
              <input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} className={inputCls} />
            </Field>
            <Field label="السعر (د.ع)">
              <input type="number" required value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} className={inputCls} />
            </Field>
            <Field label="السعر قبل الخصم (اختياري)">
              <input type="number" value={form.oldPrice ?? ""} onChange={(e) => setForm({ ...form, oldPrice: e.target.value ? Number(e.target.value) : undefined })} className={inputCls} />
            </Field>
            <Field label="التوفر">
              <select value={form.availability} onChange={(e) => setForm({ ...form, availability: e.target.value as Availability })} className={inputCls}>
                <option value="available">متوفر</option>
                <option value="low">كمية محدودة</option>
                <option value="out">غير متوفر</option>
              </select>
            </Field>
            <Field label="مميز؟">
              <label className="flex h-11 items-center gap-2 rounded-xl border border-border bg-secondary px-4">
                <input type="checkbox" checked={!!form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} className="size-4 accent-primary" />
                <span className="text-sm font-bold">عرضه في المميزة</span>
              </label>
            </Field>
          </div>
          <Field label="الوصف">
            <textarea rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className={inputCls} />
          </Field>

          <Field label="صور المنتج">
            <div className="space-y-3">
              {form.images.length > 0 && (
                <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
                  {form.images.map((src, i) => (
                    <div key={src + i} className="group relative aspect-square overflow-hidden rounded-xl border border-border bg-secondary">
                      <img src={src} alt="" className="h-full w-full object-cover" loading="lazy" />
                      <button
                        type="button"
                        onClick={() => setForm((f) => ({ ...f, images: f.images.filter((_, idx) => idx !== i) }))}
                        className="absolute left-1 top-1 rounded-full bg-destructive px-2 py-0.5 text-xs font-bold text-destructive-foreground opacity-0 transition group-hover:opacity-100"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-secondary/50 px-4 py-6 text-sm font-bold text-muted-foreground hover:border-primary hover:text-primary">
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  disabled={uploading}
                  onChange={(e) => {
                    handleFiles(e.target.files);
                    e.target.value = "";
                  }}
                />
                {uploading ? "⏳ جاري الرفع…" : "📷 اختر صور (يمكن اختيار عدة صور)"}
              </label>
              {uploadErr && <p className="text-xs font-bold text-destructive">{uploadErr}</p>}
              <p className="text-xs text-muted-foreground">الحد الأقصى لكل صورة: 5MB — JPG/PNG/WEBP</p>
            </div>
          </Field>



          <div className="flex gap-2 pt-2">
            <button type="submit" className="flex-1 rounded-xl bg-primary py-3 text-sm font-black text-primary-foreground hover:opacity-90">
              {initial ? "حفظ التغييرات" : "إضافة"}
            </button>
            <button type="button" onClick={onClose} className="rounded-xl border border-border px-6 text-sm font-bold hover:bg-secondary">
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const inputCls = "w-full rounded-xl border border-border bg-secondary px-4 py-2.5 text-sm outline-none focus:bg-card focus:ring-2 focus:ring-primary";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-bold text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

/* -------------------- Categories -------------------- */

function CategoriesAdmin() {
  const categories = useStore((s) => s.categories);
  const addCategory = useStore((s) => s.addCategory);
  const deleteCategory = useStore((s) => s.deleteCategory);
  const [name, setName] = useState("");
  const [emoji, setEmoji] = useState("📁");
  const [slug, setSlug] = useState("");

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {categories.map((c) => (
          <div key={c.id} className={`rounded-2xl border p-4 ${c.color}`}>
            <div className="flex items-start justify-between">
              <span className="text-3xl">{c.emoji}</span>
              <button
                onClick={() => confirm(`حذف قسم "${c.name}"؟`) && deleteCategory(c.id)}
                className="text-xs font-bold text-destructive hover:underline"
              >
                حذف
              </button>
            </div>
            <p className="mt-3 font-bold">{c.name}</p>
            <p className="text-xs text-muted-foreground" dir="ltr">/{c.slug}</p>
          </div>
        ))}
      </div>
      <div className="rounded-3xl border border-border bg-card p-6 shadow-soft h-fit">
        <h3 className="mb-4 text-lg font-black">إضافة قسم جديد</h3>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!name || !slug) return;
            addCategory({ name, slug, emoji, color: "bg-slate-50 border-slate-100" });
            setName(""); setSlug(""); setEmoji("📁");
          }}
          className="space-y-3"
        >
          <Field label="الاسم">
            <input required value={name} onChange={(e) => setName(e.target.value)} className={inputCls} />
          </Field>
          <Field label="المعرّف (بالإنجليزية)">
            <input required value={slug} onChange={(e) => setSlug(e.target.value.replace(/\s+/g, "-").toLowerCase())} className={inputCls} dir="ltr" />
          </Field>
          <Field label="الأيقونة">
            <input value={emoji} onChange={(e) => setEmoji(e.target.value)} className={inputCls} />
          </Field>
          <button className="w-full rounded-xl bg-primary py-3 text-sm font-black text-primary-foreground hover:opacity-90">
            إضافة
          </button>
        </form>
      </div>
    </div>
  );
}

/* -------------------- Banners -------------------- */

function BannersAdmin() {
  const banners = useStore((s) => s.banners);
  const addBanner = useStore((s) => s.addBanner);
  const deleteBanner = useStore((s) => s.deleteBanner);
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [cta, setCta] = useState("تسوق الآن");
  const [gradient, setGradient] = useState("from-primary to-emerald-700");

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="space-y-4">
        {banners.map((b) => (
          <div key={b.id} className={`relative overflow-hidden rounded-2xl bg-gradient-to-l ${b.gradient} p-6 text-white`}>
            <button
              onClick={() => confirm(`حذف عرض "${b.title}"؟`) && deleteBanner(b.id)}
              className="absolute left-4 top-4 rounded-lg bg-white/20 px-3 py-1 text-xs font-bold backdrop-blur"
            >
              حذف
            </button>
            <h3 className="text-xl font-black">{b.title}</h3>
            <p className="mt-1 text-sm text-white/85">{b.subtitle}</p>
            <p className="mt-3 text-xs text-white/70" dir="ltr">CTA: {b.cta}</p>
          </div>
        ))}
      </div>
      <div className="rounded-3xl border border-border bg-card p-6 shadow-soft h-fit">
        <h3 className="mb-4 text-lg font-black">إضافة عرض</h3>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!title) return;
            addBanner({ title, subtitle, cta, gradient });
            setTitle(""); setSubtitle("");
          }}
          className="space-y-3"
        >
          <Field label="العنوان"><input required value={title} onChange={(e) => setTitle(e.target.value)} className={inputCls} /></Field>
          <Field label="الوصف"><textarea value={subtitle} onChange={(e) => setSubtitle(e.target.value)} className={inputCls} rows={2} /></Field>
          <Field label="نص الزر"><input value={cta} onChange={(e) => setCta(e.target.value)} className={inputCls} /></Field>
          <Field label="التدرج اللوني">
            <select value={gradient} onChange={(e) => setGradient(e.target.value)} className={inputCls}>
              <option value="from-primary to-emerald-700">أخضر داكن</option>
              <option value="from-emerald-600 to-teal-700">أخضر مائل للأزرق</option>
              <option value="from-orange-500 to-red-600">برتقالي أحمر</option>
              <option value="from-slate-700 to-slate-900">رمادي فاخر</option>
            </select>
          </Field>
          <button className="w-full rounded-xl bg-primary py-3 text-sm font-black text-primary-foreground hover:opacity-90">إضافة</button>
        </form>
      </div>
    </div>
  );
}

/* -------------------- Store Info -------------------- */

function InfoAdmin() {
  const info = useStore((s) => s.info);
  const updateInfo = useStore((s) => s.updateInfo);
  const [form, setForm] = useState(info);
  const [saved, setSaved] = useState(false);

  return (
    <div className="max-w-2xl">
      <form
        onSubmit={(e) => { e.preventDefault(); updateInfo(form); setSaved(true); setTimeout(() => setSaved(false), 2000); }}
        className="space-y-4 rounded-3xl border border-border bg-card p-6 shadow-soft"
      >
        <Field label="اسم المتجر"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} /></Field>
        <Field label="الشعار"><input value={form.tagline} onChange={(e) => setForm({ ...form, tagline: e.target.value })} className={inputCls} /></Field>
        <Field label="العنوان"><input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className={inputCls} /></Field>
        <Field label="رقم الهاتف (بالصيغة الدولية بدون +)"><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputCls} dir="ltr" /></Field>
        <Field label="رقم واتساب"><input value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} className={inputCls} dir="ltr" /></Field>
        <Field label="ساعات العمل"><input value={form.hours} onChange={(e) => setForm({ ...form, hours: e.target.value })} className={inputCls} /></Field>
        <Field label="البريد الإلكتروني"><input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputCls} dir="ltr" /></Field>
        <Field label="رابط خرائط جوجل (embed src)">
          <textarea rows={3} value={form.mapEmbed} onChange={(e) => setForm({ ...form, mapEmbed: e.target.value })} className={inputCls} dir="ltr" />
        </Field>
        <div className="flex items-center gap-3">
          <button className="rounded-xl bg-primary px-6 py-3 text-sm font-black text-primary-foreground hover:opacity-90">حفظ</button>
          {saved && <span className="text-sm font-bold text-primary">✓ تم الحفظ</span>}
        </div>
      </form>
    </div>
  );
}
