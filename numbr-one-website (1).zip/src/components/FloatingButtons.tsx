import { useStore } from "@/data/store";

export function FloatingButtons() {
  const info = useStore((s) => s.info);
  const waMsg = encodeURIComponent(`مرحباً، أود الاستفسار عن منتجات ${info.name}`);
  return (
    <div className="fixed bottom-5 left-5 z-50 flex flex-col gap-3 sm:bottom-8 sm:left-8">
      <a
        href={`https://wa.me/${info.whatsapp}?text=${waMsg}`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="واتساب"
        className="group relative flex size-14 items-center justify-center rounded-full bg-whatsapp text-white shadow-xl ring-4 ring-whatsapp/20 transition hover:scale-110"
      >
        <WhatsAppIcon />
        <span className="pointer-events-none absolute right-full mr-3 whitespace-nowrap rounded-lg bg-card px-3 py-1 text-xs font-bold text-foreground opacity-0 shadow-md transition group-hover:opacity-100">
          واتساب
        </span>
      </a>
      <a
        href={`tel:+${info.phone}`}
        aria-label="اتصل بنا"
        className="group relative flex size-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-xl ring-4 ring-primary/20 transition hover:scale-110"
      >
        <PhoneIcon />
        <span className="pointer-events-none absolute right-full mr-3 whitespace-nowrap rounded-lg bg-card px-3 py-1 text-xs font-bold text-foreground opacity-0 shadow-md transition group-hover:opacity-100">
          اتصل بنا
        </span>
      </a>
    </div>
  );
}

function WhatsAppIcon() {
  return (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.174.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
      <path d="M20.52 3.449C18.24 1.245 15.24 0 12.045 0 5.463 0 .104 5.334.101 11.892c0 2.096.549 4.14 1.595 5.945L0 24l6.335-1.652c1.746.943 3.71 1.444 5.71 1.447h.006c6.585 0 11.946-5.336 11.949-11.896 0-3.176-1.24-6.165-3.495-8.411m-8.478 18.297h-.005a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.98.999-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898 1.866 1.869 2.893 4.352 2.892 6.993-.002 5.45-4.437 9.884-9.884 9.884" />
    </svg>
  );
}

function PhoneIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
    </svg>
  );
}
