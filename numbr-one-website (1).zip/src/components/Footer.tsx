import { Link } from "@tanstack/react-router";
import { useStore } from "@/data/store";

export function Footer() {
  const info = useStore((s) => s.info);
  const categories = useStore((s) => s.categories);
  const cats = categories.slice(0, 6);


  return (
    <footer className="mt-20 border-t border-border bg-card">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <h3 className="text-2xl font-black tracking-tight text-primary">
            NUMBR <span className="rounded-md bg-accent px-2 py-0.5 text-accent-foreground">ONE</span>
          </h3>
          <p className="mt-3 max-w-md text-sm text-muted-foreground">
            {info.tagline}. سوبر ماركت محلي يوفر لك كل احتياجاتك اليومية من منتجات طازجة بأسعار مناسبة.
          </p>
          <div className="mt-6 space-y-2 text-sm">
            <p className="flex items-center gap-2"><span>📍</span> {info.address}</p>
            <p className="flex items-center gap-2"><span>📞</span> {info.phone}</p>
            <p className="flex items-center gap-2"><span>🕒</span> {info.hours}</p>
          </div>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-bold text-foreground">الأقسام</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            {cats.map((c) => (
              <li key={c.id}>
                <Link to="/category/$slug" params={{ slug: c.slug }} className="hover:text-primary">
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-bold text-foreground">روابط سريعة</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/" className="hover:text-primary">الرئيسية</Link></li>
            <li><Link to="/products" className="hover:text-primary">كل المنتجات</Link></li>
            <li><Link to="/admin" className="hover:text-primary">لوحة التحكم</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} {info.name}. جميع الحقوق محفوظة.
      </div>
    </footer>
  );
}
