
-- Categories
CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  emoji text NOT NULL DEFAULT '🛒',
  color text NOT NULL DEFAULT 'bg-slate-50 border-slate-100',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories are viewable by everyone" ON public.categories FOR SELECT USING (true);

-- Products
CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category_id uuid REFERENCES public.categories(id) ON DELETE SET NULL,
  price numeric NOT NULL DEFAULT 0,
  old_price numeric,
  unit text NOT NULL DEFAULT 'قطعة',
  availability text NOT NULL DEFAULT 'available' CHECK (availability IN ('available','low','out')),
  featured boolean NOT NULL DEFAULT false,
  description text NOT NULL DEFAULT '',
  images jsonb NOT NULL DEFAULT '[]'::jsonb,
  emoji text NOT NULL DEFAULT '🛒',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.products TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products are viewable by everyone" ON public.products FOR SELECT USING (true);
CREATE INDEX products_category_id_idx ON public.products(category_id);
CREATE INDEX products_featured_idx ON public.products(featured);

-- Banners
CREATE TABLE public.banners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subtitle text NOT NULL DEFAULT '',
  cta text NOT NULL DEFAULT 'تسوق الآن',
  gradient text NOT NULL DEFAULT 'from-primary to-emerald-700',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.banners TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.banners TO authenticated;
GRANT ALL ON public.banners TO service_role;
ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;
CREATE POLICY "banners are viewable by everyone" ON public.banners FOR SELECT USING (true);

-- Store info (single row)
CREATE TABLE public.store_info (
  id int PRIMARY KEY DEFAULT 1,
  name text NOT NULL DEFAULT 'NUMBR ONE',
  tagline text NOT NULL DEFAULT '',
  address text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  whatsapp text NOT NULL DEFAULT '',
  hours text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  map_embed text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT store_info_single CHECK (id = 1)
);
GRANT SELECT ON public.store_info TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.store_info TO authenticated;
GRANT ALL ON public.store_info TO service_role;
ALTER TABLE public.store_info ENABLE ROW LEVEL SECURITY;
CREATE POLICY "store_info is viewable by everyone" ON public.store_info FOR SELECT USING (true);

-- Seed data
INSERT INTO public.store_info (id, name, tagline, address, phone, whatsapp, hours, email, map_embed) VALUES
(1, 'NUMBR ONE', 'خيارك الأول للتسوق اليومي', 'البصرة، البراضعية', '9647718776007', '9647718776007',
 'يومياً من 8:00 صباحاً حتى 12:00 منتصف الليل', 'info@numbrone.iq',
 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13932.905!2d47.7804!3d30.5085!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzDCsDMwJzMwLjYiTiA0N8KwNDYnNDkuNCJF!5e0!3m2!1sar!2siq!4v1700000000000');

INSERT INTO public.categories (slug, name, emoji, color, sort_order) VALUES
('fruits','الفواكه','🍎','bg-rose-50 border-rose-100',1),
('vegetables','الخضروات','🥬','bg-emerald-50 border-emerald-100',2),
('dairy','الألبان','🥛','bg-blue-50 border-blue-100',3),
('meat','اللحوم','🥩','bg-red-50 border-red-100',4),
('frozen','المجمدات','🧊','bg-sky-50 border-sky-100',5),
('drinks','المشروبات','🥤','bg-cyan-50 border-cyan-100',6),
('snacks','الوجبات الخفيفة','🍫','bg-amber-50 border-amber-100',7),
('bakery','المخبوزات','🥖','bg-orange-50 border-orange-100',8),
('rice-pasta','الأرز والمعكرونة','🍚','bg-yellow-50 border-yellow-100',9),
('oils','الزيوت','🫒','bg-lime-50 border-lime-100',10),
('cleaning','المنظفات','🧴','bg-indigo-50 border-indigo-100',11),
('personal','العناية الشخصية','🧼','bg-purple-50 border-purple-100',12),
('baby','منتجات الأطفال','🍼','bg-pink-50 border-pink-100',13),
('household','الأدوات المنزلية','🏠','bg-slate-50 border-slate-100',14);

INSERT INTO public.banners (title, subtitle, cta, gradient, sort_order) VALUES
('عروض نهاية الأسبوع','خصومات تصل إلى 30% على الخضروات والفواكه الطازجة','تسوق العروض','from-primary to-emerald-700',1),
('توصيل مجاني','لجميع الطلبات فوق 25,000 دينار داخل البصرة','اطلب الآن','from-emerald-600 to-teal-700',2);

-- Seed products
INSERT INTO public.products (name, category_id, price, old_price, unit, availability, featured, description, emoji) VALUES
('تفاح أحمر مستورد', (SELECT id FROM public.categories WHERE slug='fruits'), 3500, 4000, 'كغم', 'available', true, 'تفاح أحمر طازج مستورد بأعلى جودة، مقرمش وحلو المذاق.', '🍎'),
('موز أصفر طازج', (SELECT id FROM public.categories WHERE slug='fruits'), 2000, NULL, 'كغم', 'available', true, 'موز طازج غني بالبوتاسيوم.', '🍌'),
('برتقال أبو صرة', (SELECT id FROM public.categories WHERE slug='fruits'), 2500, NULL, 'كغم', 'low', false, 'برتقال حلو ممتاز غني بفيتامين سي.', '🍊'),
('طماطم محلية', (SELECT id FROM public.categories WHERE slug='vegetables'), 1500, NULL, 'كغم', 'available', true, 'طماطم حمراء طازجة من المزارع المحلية.', '🍅'),
('خيار طازج', (SELECT id FROM public.categories WHERE slug='vegetables'), 1250, NULL, 'كغم', 'available', false, 'خيار مقرمش طازج يومياً.', '🥒'),
('خس أخضر', (SELECT id FROM public.categories WHERE slug='vegetables'), 1000, NULL, 'قطعة', 'available', false, 'خس طازج للسلطات.', '🥬'),
('بطاطا بيضاء', (SELECT id FROM public.categories WHERE slug='vegetables'), 1750, NULL, 'كغم', 'available', false, 'بطاطا بيضاء ممتازة للطبخ والقلي.', '🥔'),
('حليب المراعي كامل الدسم', (SELECT id FROM public.categories WHERE slug='dairy'), 2000, NULL, 'لتر', 'available', true, 'حليب طازج كامل الدسم.', '🥛'),
('لبن رائب طبيعي', (SELECT id FROM public.categories WHERE slug='dairy'), 1500, NULL, 'قطعة', 'available', false, 'لبن رائب طازج غني بالبروبيوتيك.', '🥛'),
('جبنة بيضاء رومي', (SELECT id FROM public.categories WHERE slug='dairy'), 8500, NULL, 'كغم', 'low', false, 'جبنة رومي فاخرة مالحة.', '🧀'),
('بيض بلدي 30 حبة', (SELECT id FROM public.categories WHERE slug='dairy'), 6500, NULL, 'طبقة', 'available', false, 'بيض بلدي طازج.', '🥚'),
('دجاج طازج كامل', (SELECT id FROM public.categories WHERE slug='meat'), 6000, NULL, 'قطعة', 'available', true, 'دجاج طازج بلدي.', '🍗'),
('لحم بقر مفروم', (SELECT id FROM public.categories WHERE slug='meat'), 15000, NULL, 'كغم', 'available', false, 'لحم بقر طازج مفروم درجة أولى.', '🥩'),
('لحم غنم طازج', (SELECT id FROM public.categories WHERE slug='meat'), 22000, NULL, 'كغم', 'low', false, 'لحم غنم بلدي فاخر.', '🥩'),
('بازلاء مجمدة', (SELECT id FROM public.categories WHERE slug='frozen'), 3500, NULL, 'كيس', 'available', false, 'بازلاء خضراء مجمدة.', '🫛'),
('بطاطا مقلية مجمدة', (SELECT id FROM public.categories WHERE slug='frozen'), 4500, NULL, 'كيس', 'available', false, 'بطاطا مقلية جاهزة.', '🍟'),
('مياه معدنية 1.5 لتر', (SELECT id FROM public.categories WHERE slug='drinks'), 500, NULL, 'قنينة', 'available', false, 'مياه معدنية نقية.', '💧'),
('بيبسي 2 لتر', (SELECT id FROM public.categories WHERE slug='drinks'), 1500, NULL, 'قنينة', 'available', true, 'بيبسي منعش عائلي.', '🥤'),
('عصير برتقال طبيعي', (SELECT id FROM public.categories WHERE slug='drinks'), 2500, NULL, 'لتر', 'available', false, 'عصير برتقال طبيعي 100%.', '🧃'),
('شوكولاتة سنيكرز', (SELECT id FROM public.categories WHERE slug='snacks'), 1000, NULL, 'قطعة', 'available', false, 'شوكولاتة سنيكرز الأصلية.', '🍫'),
('بسكويت أوريو', (SELECT id FROM public.categories WHERE slug='snacks'), 1250, NULL, 'علبة', 'available', false, 'بسكويت أوريو المفضل.', '🍪'),
('شيبس ليز', (SELECT id FROM public.categories WHERE slug='snacks'), 750, NULL, 'كيس', 'available', false, 'شيبس ليز مقرمش.', '🍟'),
('خبز صمون طازج', (SELECT id FROM public.categories WHERE slug='bakery'), 250, NULL, 'قطعة', 'available', true, 'خبز صمون طازج يومياً.', '🥖'),
('كعك بالسمسم', (SELECT id FROM public.categories WHERE slug='bakery'), 500, NULL, 'قطعة', 'available', false, 'كعك تقليدي بالسمسم.', '🥨'),
('أرز بسمتي هندي', (SELECT id FROM public.categories WHERE slug='rice-pasta'), 12000, NULL, 'كيس 5 كغم', 'available', true, 'أرز بسمتي فاخر طويل الحبة.', '🍚'),
('معكرونة إيطالية', (SELECT id FROM public.categories WHERE slug='rice-pasta'), 1500, NULL, 'كيس', 'available', false, 'معكرونة إيطالية درجة أولى.', '🍝'),
('زيت زيتون بكر ممتاز', (SELECT id FROM public.categories WHERE slug='oils'), 18500, 22000, 'لتر', 'available', true, 'زيت زيتون بكر ممتاز عصرة أولى.', '🫒'),
('زيت دوار الشمس', (SELECT id FROM public.categories WHERE slug='oils'), 4500, NULL, 'لتر', 'available', false, 'زيت دوار الشمس للطبخ اليومي.', '🌻'),
('سائل جلي فيري', (SELECT id FROM public.categories WHERE slug='cleaning'), 3000, NULL, 'قنينة', 'available', false, 'سائل جلي فعال ضد الدهون.', '🧴'),
('مسحوق غسيل أرييل', (SELECT id FROM public.categories WHERE slug='cleaning'), 8500, NULL, 'كيس 3 كغم', 'available', false, 'مسحوق غسيل للملابس.', '🧺'),
('شامبو هيد اند شولدرز', (SELECT id FROM public.categories WHERE slug='personal'), 5500, NULL, 'قنينة', 'available', false, 'شامبو ضد القشرة.', '🧴'),
('معجون أسنان سيجنال', (SELECT id FROM public.categories WHERE slug='personal'), 2000, NULL, 'قطعة', 'available', false, 'معجون أسنان للحماية الكاملة.', '🪥'),
('حفاضات بامبرز مقاس 4', (SELECT id FROM public.categories WHERE slug='baby'), 12500, NULL, 'علبة', 'available', false, 'حفاضات بامبرز مريحة للأطفال.', '🍼'),
('حليب أطفال نان 1', (SELECT id FROM public.categories WHERE slug='baby'), 15000, NULL, 'علبة', 'low', false, 'حليب أطفال نان للرضع.', '🍼'),
('أكياس قمامة كبيرة', (SELECT id FROM public.categories WHERE slug='household'), 2500, NULL, 'لفة', 'available', false, 'أكياس قمامة متينة كبيرة.', '🗑️'),
('ورق ألمنيوم', (SELECT id FROM public.categories WHERE slug='household'), 3500, NULL, 'لفة', 'out', false, 'ورق ألمنيوم عالي الجودة.', '📜');
