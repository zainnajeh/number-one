import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useStore } from "@/data/store";

export function Header() {
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  const categories = useStore((s) => s.categories);

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (q.trim()) navigate({ to: "/products", search: { q: q.trim() } as never });
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-card/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 sm:h-20 sm:gap-6">
        <Link to="/" className="shrink-0">
          <h1 className="text-xl font-black tracking-tight text-primary sm:text-2xl">
            NUMBR <span className="text-accent-foreground bg-accent px-2 py-0.5 rounded-md">ONE</span>
          </h1>
        </Link>

        <form onSubmit={onSubmit} className="relative min-w-0 flex-1 max-w-2xl">
          <input
            type="text"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث عن منتجاتك..."
            className="w-full rounded-2xl border-none bg-secondary py-2.5 pr-11 pl-4 text-sm outline-none transition focus:bg-card focus:ring-2 focus:ring-primary sm:py-3 sm:text-base"
          />
          <span className="pointer-events-none absolute inset-y-0 right-4 flex items-center text-muted-foreground">
            <SearchIcon />
          </span>
        </form>

        <nav className="hidden shrink-0 items-center gap-5 text-sm font-bold text-muted-foreground md:flex">
          <Link to="/" activeOptions={{ exact: true }} activeProps={{ className: "text-primary" }} className="hover:text-primary">الرئيسية</Link>
          <Link to="/products" activeProps={{ className: "text-primary" }} className="hover:text-primary">المنتجات</Link>
          <Link to="/admin" className="hover:text-primary">لوحة التحكم</Link>
        </nav>
      </div>

      {/* Category chips row */}
      <div className="border-t border-border/60 bg-card/50">
        <div className="mx-auto max-w-7xl overflow-x-auto px-4 no-scrollbar">
          <div className="flex gap-2 py-2">
            <Link
              to="/products"
              className="shrink-0 rounded-full border border-border bg-card px-4 py-1.5 text-xs font-bold text-foreground hover:border-primary hover:text-primary"
            >
              كل الأقسام
            </Link>
            {categories.map((c) => (
              <Link
                key={c.id}
                to="/category/$slug"
                params={{ slug: c.slug }}
                className="shrink-0 rounded-full border border-border bg-card px-4 py-1.5 text-xs font-bold text-foreground hover:border-primary hover:text-primary"
              >
                <span className="ml-1">{c.emoji}</span>
                {c.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}

function SearchIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
}
