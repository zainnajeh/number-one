import { Link } from "@tanstack/react-router";
import { availabilityClass, availabilityLabel, formatPrice, type Product, useStore } from "@/data/store";

export function ProductCard({ product }: { product: Product }) {
  const category = useStore((s) => s.categories.find((c) => c.id === product.categoryId));
  const isOut = product.availability === "out";
  const discount = product.oldPrice && product.oldPrice > product.price
    ? Math.round((1 - product.price / product.oldPrice) * 100)
    : null;

  return (
    <Link
      to="/product/$id"
      params={{ id: product.id }}
      className="group flex flex-col rounded-3xl border border-border bg-card p-3 transition hover-lift"
    >
      <div className="relative mb-3 aspect-square overflow-hidden rounded-2xl bg-secondary">
        <div className={`flex h-full w-full items-center justify-center text-6xl transition ${isOut ? "grayscale opacity-60" : "group-hover:scale-110"} duration-500`}>
          <span aria-hidden>{product.emoji}</span>
        </div>
        <span className={`absolute top-2 right-2 rounded-full border px-2 py-0.5 text-[10px] font-bold ${availabilityClass[product.availability]}`}>
          {availabilityLabel[product.availability]}
        </span>
        {discount !== null && !isOut && (
          <span className="absolute top-2 left-2 rounded-full bg-destructive px-2 py-0.5 text-[10px] font-black text-destructive-foreground">
            خصم {discount}%
          </span>
        )}
      </div>
      <div className="mb-1 flex items-center gap-1 text-[11px] text-muted-foreground">
        <span>{category?.name}</span>
        <span>•</span>
        <span>{product.unit}</span>
      </div>
      <h4 className="mb-3 line-clamp-2 min-h-[2.5rem] text-sm font-bold text-foreground">
        {product.name}
      </h4>
      <div className="mt-auto flex items-center justify-between">
        <div className="flex flex-col leading-tight">
          <span className="text-base font-black text-primary sm:text-lg">{formatPrice(product.price)}</span>
          {product.oldPrice && (
            <span className="text-xs text-muted-foreground line-through">{formatPrice(product.oldPrice)}</span>
          )}
        </div>
        <span className="flex size-9 items-center justify-center rounded-xl bg-secondary text-lg font-black text-foreground transition group-hover:bg-primary group-hover:text-primary-foreground">
          →
        </span>
      </div>
    </Link>
  );
}
