import { create } from "zustand";
import { supabase } from "@/integrations/supabase/client";
import {
  createProduct as fnCreateProduct,
  updateProduct as fnUpdateProduct,
  deleteProduct as fnDeleteProduct,
  createCategory as fnCreateCategory,
  deleteCategory as fnDeleteCategory,
  createBanner as fnCreateBanner,
  deleteBanner as fnDeleteBanner,
  updateStoreInfo as fnUpdateStoreInfo,
  verifyAdminPassword as fnVerifyPassword,
} from "@/lib/store-api.functions";

export type Availability = "available" | "low" | "out";

export interface Category {
  id: string;
  slug: string;
  name: string;
  emoji: string;
  color: string;
  sortOrder?: number;
}

export interface Product {
  id: string;
  name: string;
  categoryId: string | null;
  price: number;
  oldPrice?: number;
  unit: string;
  availability: Availability;
  featured?: boolean;
  description: string;
  images: string[];
  emoji: string;
  createdAt: number;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  cta: string;
  gradient: string;
  sortOrder?: number;
}

export interface StoreInfo {
  name: string;
  tagline: string;
  address: string;
  phone: string;
  whatsapp: string;
  hours: string;
  email: string;
  mapEmbed: string;
}

/* ---------------- Row mappers ---------------- */

interface ProductRow {
  id: string;
  name: string;
  category_id: string | null;
  price: number | string;
  old_price: number | string | null;
  unit: string;
  availability: string;
  featured: boolean;
  description: string;
  images: unknown;
  emoji: string;
  created_at: string;
}

interface CategoryRow {
  id: string;
  slug: string;
  name: string;
  emoji: string;
  color: string;
  sort_order: number;
}

interface BannerRow {
  id: string;
  title: string;
  subtitle: string;
  cta: string;
  gradient: string;
  sort_order: number;
}

interface StoreInfoRow {
  name: string;
  tagline: string;
  address: string;
  phone: string;
  whatsapp: string;
  hours: string;
  email: string;
  map_embed: string;
}

function toProduct(r: ProductRow): Product {
  return {
    id: r.id,
    name: r.name,
    categoryId: r.category_id,
    price: Number(r.price),
    oldPrice: r.old_price != null ? Number(r.old_price) : undefined,
    unit: r.unit,
    availability: (["available", "low", "out"].includes(r.availability) ? r.availability : "available") as Availability,
    featured: r.featured,
    description: r.description,
    images: Array.isArray(r.images) ? (r.images as string[]) : [],
    emoji: r.emoji,
    createdAt: new Date(r.created_at).getTime(),
  };
}

function toCategory(r: CategoryRow): Category {
  return { id: r.id, slug: r.slug, name: r.name, emoji: r.emoji, color: r.color, sortOrder: r.sort_order };
}

function toBanner(r: BannerRow): Banner {
  return { id: r.id, title: r.title, subtitle: r.subtitle, cta: r.cta, gradient: r.gradient, sortOrder: r.sort_order };
}

function toInfo(r: StoreInfoRow): StoreInfo {
  return {
    name: r.name,
    tagline: r.tagline,
    address: r.address,
    phone: r.phone,
    whatsapp: r.whatsapp,
    hours: r.hours,
    email: r.email,
    mapEmbed: r.map_embed,
  };
}

/* ---------------- Defaults (for SSR / first paint) ---------------- */

const defaultInfo: StoreInfo = {
  name: "NUMBR ONE",
  tagline: "خيارك الأول للتسوق اليومي",
  address: "البصرة، البراضعية",
  phone: "9647718776007",
  whatsapp: "9647718776007",
  hours: "يومياً من 8:00 صباحاً حتى 12:00 منتصف الليل",
  email: "info@numbrone.iq",
  mapEmbed: "",
};

/* ---------------- Store ---------------- */

interface StoreState {
  categories: Category[];
  products: Product[];
  banners: Banner[];
  info: StoreInfo;
  isAdmin: boolean;
  adminPassword: string | null;
  loaded: boolean;
  loading: boolean;

  hydrate: () => Promise<void>;

  addProduct: (p: Omit<Product, "id" | "createdAt">) => Promise<void>;
  updateProduct: (id: string, patch: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;

  addCategory: (c: Omit<Category, "id">) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;

  addBanner: (b: Omit<Banner, "id">) => Promise<void>;
  deleteBanner: (id: string) => Promise<void>;

  updateInfo: (patch: Partial<StoreInfo>) => Promise<void>;

  login: (password: string) => Promise<boolean>;
  logout: () => void;
  resetAll: () => Promise<void>;
}

export const useStore = create<StoreState>()((set, get) => ({
  categories: [],
  products: [],
  banners: [],
  info: defaultInfo,
  isAdmin: false,
  adminPassword: null,
  loaded: false,
  loading: false,

  hydrate: async () => {
    if (get().loading) return;
    set({ loading: true });
    try {
      const [cats, prods, bans, inf] = await Promise.all([
        supabase.from("categories").select("*").order("sort_order", { ascending: true }),
        supabase.from("products").select("*").order("created_at", { ascending: false }),
        supabase.from("banners").select("*").order("sort_order", { ascending: true }),
        supabase.from("store_info").select("*").eq("id", 1).maybeSingle(),
      ]);
      set({
        categories: (cats.data ?? []).map((r) => toCategory(r as unknown as CategoryRow)),
        products: (prods.data ?? []).map((r) => toProduct(r as unknown as ProductRow)),
        banners: (bans.data ?? []).map((r) => toBanner(r as unknown as BannerRow)),
        info: inf.data ? toInfo(inf.data as unknown as StoreInfoRow) : defaultInfo,
        loaded: true,
        loading: false,
      });
    } catch (e) {
      console.error("hydrate failed", e);
      set({ loading: false });
    }
  },

  addProduct: async (p) => {
    const pw = get().adminPassword;
    if (!pw) throw new Error("Not authenticated");
    await fnCreateProduct({
      data: {
        password: pw,
        product: {
          name: p.name,
          categoryId: p.categoryId ?? null,
          price: p.price,
          oldPrice: p.oldPrice ?? null,
          unit: p.unit,
          availability: p.availability,
          featured: !!p.featured,
          description: p.description,
          images: p.images,
          emoji: p.emoji,
        },
      },
    });
    await get().hydrate();
  },

  updateProduct: async (id, patch) => {
    const pw = get().adminPassword;
    if (!pw) throw new Error("Not authenticated");
    await fnUpdateProduct({
      data: {
        password: pw,
        id,
        patch: {
          name: patch.name,
          categoryId: patch.categoryId,
          price: patch.price,
          oldPrice: patch.oldPrice,
          unit: patch.unit,
          availability: patch.availability,
          featured: patch.featured,
          description: patch.description,
          images: patch.images,
          emoji: patch.emoji,
        },
      },
    });
    await get().hydrate();
  },

  deleteProduct: async (id) => {
    const pw = get().adminPassword;
    if (!pw) throw new Error("Not authenticated");
    await fnDeleteProduct({ data: { password: pw, id } });
    set({ products: get().products.filter((p) => p.id !== id) });
  },

  addCategory: async (c) => {
    const pw = get().adminPassword;
    if (!pw) throw new Error("Not authenticated");
    await fnCreateCategory({
      data: {
        password: pw,
        category: {
          slug: c.slug,
          name: c.name,
          emoji: c.emoji,
          color: c.color,
          sortOrder: c.sortOrder,
        },
      },
    });
    await get().hydrate();
  },

  deleteCategory: async (id) => {
    const pw = get().adminPassword;
    if (!pw) throw new Error("Not authenticated");
    await fnDeleteCategory({ data: { password: pw, id } });
    set({ categories: get().categories.filter((c) => c.id !== id) });
  },

  addBanner: async (b) => {
    const pw = get().adminPassword;
    if (!pw) throw new Error("Not authenticated");
    await fnCreateBanner({
      data: {
        password: pw,
        banner: {
          title: b.title,
          subtitle: b.subtitle,
          cta: b.cta,
          gradient: b.gradient,
          sortOrder: b.sortOrder,
        },
      },
    });
    await get().hydrate();
  },

  deleteBanner: async (id) => {
    const pw = get().adminPassword;
    if (!pw) throw new Error("Not authenticated");
    await fnDeleteBanner({ data: { password: pw, id } });
    set({ banners: get().banners.filter((b) => b.id !== id) });
  },

  updateInfo: async (patch) => {
    const pw = get().adminPassword;
    if (!pw) throw new Error("Not authenticated");
    await fnUpdateStoreInfo({ data: { password: pw, patch } });
    set({ info: { ...get().info, ...patch } });
  },

  login: async (password) => {
    try {
      await fnVerifyPassword({ data: { password } });
      set({ isAdmin: true, adminPassword: password });
      return true;
    } catch {
      return false;
    }
  },

  logout: () => set({ isAdmin: false, adminPassword: null }),

  resetAll: async () => {
    // Refresh from database
    await get().hydrate();
  },
}));

/* ---------------- Helpers ---------------- */

export const availabilityLabel: Record<Availability, string> = {
  available: "متوفر",
  low: "كمية محدودة",
  out: "غير متوفر",
};

export const availabilityClass: Record<Availability, string> = {
  available: "bg-emerald-100 text-emerald-800 border-emerald-200",
  low: "bg-amber-100 text-amber-800 border-amber-200",
  out: "bg-slate-200 text-slate-600 border-slate-300",
};

export function formatPrice(n: number) {
  return new Intl.NumberFormat("ar-IQ").format(n) + " د.ع";
}
